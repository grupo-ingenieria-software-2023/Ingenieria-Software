from django.shortcuts import render

# Create your views here.
def index(req):
    return render(req, "index.html")

def menu(req):
    return render(req, "menu.html")

def contacto(req):
    return render(req, "contacto.html")

def nosotros(req):
    return render(req, "nosotros.html")